Readme


Software requirments : Catia V5 R21

Open /Parts of 3D model/final.CATProduct
